<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee FORM</title>
</head>

<body>
    <form method="post" action="untitled2.php">
        <h3 align="center">Employee Form</h3>
        <fieldset>
            <hr>
            <label> Name:<input type="text" autofocus placeholder="Enter First Name Here..." maxlength="20" name="fname" /></label><br><br>
            <label>
                First Name:<input type="text" autofocus placeholder="Enter First Name Here..." maxlength="15" name="firname" /></label><br><br>
            <label>
                Last Name:<input type="text" autofocus placeholder="Enter First Name Here..." maxlength="18" name="lname" /></label><br><br>
            <label>
                Job role:<input type="text" autofocus placeholder="Enter First Name Here..." maxlength="15" name="role" /></label>
            <br><br>
            DOB :<input type="date" name="date" /><br><br>&nbsp;<span>Upload Qualification File :<input type="file" name="uploadfile" multiple accept=".jpg,.jpeg,.png" /></span>
            Gender :<input type="radio" id="G1" name="Gender" value="Male" /><label for="G1">Male</label>&nbsp;&nbsp;
            <input type="radio" id="G2" name="Gender" value="Female" /><span>Female</span>
            <hr>
            <input type="checkbox" name="checkbox" /> Accept Terms And Condition
            <hr />
            Address :<textarea rows="5" placeholder="Enter Address Here.." name="address" maxlength="200"></textarea><br><br>
            MOB No.<input type="text" name="mobno" maxlength="12">
            <hr>

            <h4 align="center">Person to notify in a case of Emergency</h4>
            <br>
            Name :<input type="text" maxlength="20" name="emename"> &nbsp;&nbsp; <span>MOB No. <input type="text" maxlength="12" name="ememobno"></span>
            <hr>
            COMMENT:<textarea rows="5" placeholder="Enter the Comment.." maxlength="200" name="comment"></textarea><br><br>
            <input type="submit" name="submit" value="next">
        </fieldset>
    </form>
</body>

</html>