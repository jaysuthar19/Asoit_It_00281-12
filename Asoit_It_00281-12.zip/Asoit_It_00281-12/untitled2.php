<?php
if (isset($_POST["submit"])) {
    if (isset($_POST["fname"]) &&  isset($_POST["firname"]) && isset($_POST["lname"]) && isset($_POST["role"])   && isset($_POST["date"])  && isset($_POST["uploadfile"]) && isset($_POST["Gender"])   && isset($_POST["checkbox"])   && isset($_POST["address"]) && isset($_POST["emename"]) && isset($_POST["ememobno"]) && isset($_POST["comment"])) {
        $fname = $_POST["fname"];
        $firname = $_POST["firname"];
        $lname = $_POST["lname"];
        $date = $_POST["date"];
        $role = $_POST["role"];
        $male = $_POST["male"];
        $Gender = $_POST["Gender"];
        $checkbox = $_POST["checkbox"];
        $address = $_POST["address"];
        $emename = $_POST["emename"];
        $mobno = $_POST["mobno"];
        $ememobno = $_POST["ememobno"];
        $comment = $_POST["comment"];
    }
}
?>

<h3 align="center">Employee Form</h3>
<fieldset>
    <label> Name:<input type="text" value="<?php echo $fname; ?>" /></label><br><br>
    <label>
        First Name:<input type="text" value="<?php echo $firname; ?>" /></label><br><br>
    <label>
        Last Name:<input type="text" name="lname" value="<?php echo $lname; ?>" /></label><br><br>
    <label>
        Job role:<input type="text" name="role" value="<?php echo $role; ?>" /></label>
    <br><br>
    DOB :<input type="date" name="date" /><br><br>&nbsp;<span>Upload Qualification File :<input type="file" name="uploadfile" value="<?php echo $uploadfile; ?>" /></span>
    Gender :<input type="text" id="G1" name="male" name="female" value="<?php echo $Gender; ?>" />
    <hr>
    <input type="checkbox" name="checkbox" value="<?php echo $checkbox; ?>" /> Accept Terms And Condition
    <hr />
    Address :<textarea rows="5" name="address" value="<?php echo $address; ?>"></textarea><br><br>
    MOB No.<input type="text" name="mobno" value="<?php echo $mobno; ?>">
    <hr>

    <h4 align="center">Person to notify in a case of Emergency</h4>
    <br>
    Name :<input type="text" name="emename" value="<?php echo $emename; ?>"> &nbsp;&nbsp; <span>MOB No. <input type="text" name="ememobno" value="<?php echo $ememobno; ?>"></span>
    <hr>
    COMMENT:<textarea rows="5" name="comment" value="<?php echo $comment; ?>"></textarea><br><br>
</fieldset>